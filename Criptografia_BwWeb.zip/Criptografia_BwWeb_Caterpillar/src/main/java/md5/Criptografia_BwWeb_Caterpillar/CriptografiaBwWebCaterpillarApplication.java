package md5.Criptografia_BwWeb_Caterpillar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CriptografiaBwWebCaterpillarApplication {

	public static void main(String[] args) {
		SpringApplication.run(CriptografiaBwWebCaterpillarApplication.class, args);
	}

}
