package md5.Criptografia_BwWeb_Caterpillar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CriptografiaBwWebCaterpillarApplicationTests {

	@Test
	void contextLoads() {
	}

}
